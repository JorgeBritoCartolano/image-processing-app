import boto3
from PIL import Image
import os
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
sns_client = boto3.client('sns')

# Environment variables for flexibility
OUTPUT_BUCKET = os.getenv('OUTPUT_BUCKET')
SNS_TOPIC_ARN = os.getenv('SNS_TOPIC_ARN')

def lambda_handler(event, context):
    try:
        # Extract information from the event
        input_bucket = event['Records'][0]['s3']['bucket']['name']
        input_key = event['Records'][0]['s3']['object']['key']
        output_key = 'grayscale-' + input_key

        download_path = f'/tmp/{input_key}'
        upload_path = f'/tmp/{output_key}'

        # Download the file from S3
        s3_client.download_file(input_bucket, input_key, download_path)
        logger.info(f'File {input_key} downloaded from {input_bucket} to {download_path}')

        # Process the image
        with Image.open(download_path) as img:
            grayscale_img = img.convert('L')
            grayscale_img.save(upload_path)
        logger.info(f'Image converted to grayscale and saved at {upload_path}')

        # Upload the processed image to S3
        s3_client.upload_file(upload_path, OUTPUT_BUCKET, output_key)
        logger.info(f'Processed image uploaded to {OUTPUT_BUCKET}/{output_key}')

        # Send notification to SNS
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject="Image Processing Complete",
            Message=f'The image {input_key} has been processed and saved in {OUTPUT_BUCKET}/{output_key}.'
        )
        logger.info(f'Notification sent to SNS Topic: {SNS_TOPIC_ARN}')

        # Clean up temporary files
        os.remove(download_path)
        os.remove(upload_path)
        logger.info(f'Temporary files deleted: {download_path} and {upload_path}')

        return {
            'statusCode': 200,
            'body': f'Image converted to grayscale and uploaded to {OUTPUT_BUCKET}/{output_key}'
        }

    except FileNotFoundError as e:
        logger.error(f'File not found: {str(e)}')
        return {
            'statusCode': 404,
            'body': f'Error: file not found - {str(e)}'
        }

    except boto3.exceptions.Boto3Error as e:
        logger.error(f'Error in S3 operation: {str(e)}')
        return {
            'statusCode': 500,
            'body': f'Error processing the image: {str(e)}'
        }

    except Exception as e:
        logger.error(f'Unexpected error: {str(e)}')
        return {
            'statusCode': 500,
            'body': f'Unexpected error processing the image: {str(e)}'
        }