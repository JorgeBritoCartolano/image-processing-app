import boto3
import logging
import json
import urllib3

s3Client = boto3.client('s3')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']

    responseBody = {
        'Status': responseStatus,
        'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
        'PhysicalResourceId': physicalResourceId or context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': noEcho,
        'Data': responseData
    }

    json_responseBody = json.dumps(responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    http = urllib3.PoolManager()
    response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)

    print("Status code: ", response.status)
    print("Response: ", response.data)

def addBucketNotification(bucketName, notificationId, functionArn):
    notificationResponse = s3Client.put_bucket_notification_configuration(
        Bucket=bucketName,
        NotificationConfiguration={
            'LambdaFunctionConfigurations': [
                {
                    'Id': notificationId,
                    'LambdaFunctionArn': functionArn,
                    'Events': [
                        's3:ObjectCreated:*'
                    ]
                },
            ]
        }
    )
    return notificationResponse

def create(properties, physical_id, context):
    bucketName = properties['S3Bucket']
    notificationId = properties['NotificationId']
    functionArn = properties['FunctionARN']
    response = addBucketNotification(bucketName, notificationId, functionArn)
    logger.info('AddBucketNotification response: %s' % json.dumps(response))
    return 'SUCCESS', physical_id

def update(properties, physical_id, context):
    return 'SUCCESS', None

def delete(properties, physical_id, context):
    return 'SUCCESS', None

def handler(event, context):
    logger.info('Received event: %s' % json.dumps(event))

    status = 'FAILED'
    new_physical_id = None

    try:
        properties = event.get('ResourceProperties')
        physical_id = event.get('PhysicalResourceId')

        status, new_physical_id = {
            'Create': lambda props, pid: create(props, pid, context),
            'Update': lambda props, pid: update(props, pid, context),
            'Delete': lambda props, pid: delete(props, pid, context)
        }.get(event['RequestType'], lambda x, y: ('FAILED', None))(properties, physical_id)
    except Exception as e:
        logger.error('Exception: %s' % e)
    finally:
        send(event, context, status, {}, new_physical_id)